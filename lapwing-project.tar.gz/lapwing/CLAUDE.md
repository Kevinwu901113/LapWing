# CLAUDE.md

## 项目概述

Lapwing 是一个个人 AI 伴侣 & 智能助手系统，运行在 PVE 虚拟机（6核8G，Ubuntu 22.04）上。
她通过 Telegram 与用户交互，有温柔知性的固定人格，未来会扩展 Agent 团队和自主浏览能力。

## 技术栈

- **语言**: Python 3.11+
- **聊天平台**: Telegram（python-telegram-bot）
- **LLM**: OpenAI 兼容格式的第三方 provider（GLM、MiniMax 等），通过 base_url 切换
- **数据库**: 当前阶段用内存，后续迁移到 SQLite + ChromaDB
- **部署**: systemd service on Ubuntu 22.04 VM

## 项目结构约定

- 所有 Prompt 存放在 `prompts/` 目录，使用 `.md` 格式，通过 `src/core/prompt_loader.py` 加载
- 不要把 prompt 内容硬编码在 Python 文件中
- 环境变量存放在 `config/.env`，通过 `config/settings.py` 统一管理
- 新增 Agent 放在 `src/agents/` 下，每个 Agent 一个文件
- 新增工具放在 `src/tools/` 下

## 编码风格

- 使用 async/await 处理所有 I/O 操作
- 类型注解（type hints）尽量完整
- 中文注释，英文代码
- 日志使用 Python logging 模块，输出到 `logs/` 目录
- 错误处理要完善，Bot 不能因为单次 API 调用失败而崩溃

## Lapwing 的人格要求

修改 Lapwing 的行为时，优先修改 `prompts/lapwing.md`，而不是改代码逻辑。
她的核心性格是：温柔体贴 + 冷静知性，像一个温和的青年研究者。
说话自然不做作，偶尔带一点书卷气。不用额外的语气词和表情符号。
交流语言以中文为主。

## 常用命令

```bash
# 启动
source venv/bin/activate && python main.py

# 查看日志
tail -f logs/lapwing.log

# 重启服务
sudo systemctl restart lapwing
```

## 当前开发阶段

Phase 1 - 基础搭建：Telegram Bot + 人格对话 + 对话记忆

### Phase 1 的边界
- ✅ Telegram 私聊时直接回复所有消息
- ✅ 稳定的人格表现
- ✅ 当前对话的上下文记忆
- ✅ /reload 命令热加载人格 prompt
- ❌ 不需要做 Agent 团队（Phase 2）
- ❌ 不需要做自主浏览（Phase 3）
- ❌ 不需要做桌面应用（Phase 4）

## 注意事项

- Telegram 消息有 4096 字符限制，长回复需要分段发送
- LLM API 调用可能失败，必须有 try/except 和友好的错误提示
- 对话历史保留最近 20 轮（40 条消息），避免 token 超限
- LLM 通过 OpenAI 兼容格式接入，切换模型只需改 config/.env 中的 LLM_BASE_URL 和 LLM_MODEL
- config/.env 不要提交到 git
