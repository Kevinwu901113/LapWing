"""对话记忆管理。

Phase 1: 使用内存存储，重启后清空。
Phase 2: 迁移到 SQLite 持久化存储。
"""

import logging

logger = logging.getLogger("lapwing.memory")


class ConversationMemory:
    """管理对话历史的存取。

    当前版本使用内存存储。后续版本将支持：
    - SQLite 持久化
    - 向量数据库语义检索
    - 记忆衰减和归档
    """

    def __init__(self):
        self._store: dict[str, list[dict]] = {}
        logger.info("对话记忆已初始化（内存模式）")

    def get(self, channel_id: str) -> list[dict]:
        """获取指定频道的对话历史。"""
        if channel_id not in self._store:
            self._store[channel_id] = []
        return self._store[channel_id]

    def append(self, channel_id: str, role: str, content: str) -> None:
        """追加一条消息到对话历史。"""
        history = self.get(channel_id)
        history.append({"role": role, "content": content})

    def clear(self, channel_id: str) -> None:
        """清除指定频道的对话历史。"""
        self._store.pop(channel_id, None)
        logger.info(f"已清除频道 {channel_id} 的对话记忆")

    def clear_all(self) -> None:
        """清除所有对话历史。"""
        self._store.clear()
        logger.info("已清除所有对话记忆")
